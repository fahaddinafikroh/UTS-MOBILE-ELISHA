package com.example.tokoelisha1;

import java.util.List;

public class Value {
    String value;
    String message;
    List<DataBedak> result;

    public String getValue(){
        return value;
    }
    public String getMessage(){
        return message;
    }
    public List<DataBedak> getResult(){
        return result;
    }
}
