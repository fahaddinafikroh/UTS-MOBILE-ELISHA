package com.example.tokoelisha1;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainLogin extends AppCompatActivity {

    public static final String URL = "http://192.168.152.142:8080/mobile2/UTS_ELISHA/";
    ImageButton imgbtnLogin;
    EditText etEmail, etPassword;
    TextView tvRegister;
    Button btnDisplay;

    SharedPreferences sharedPreferences;
    ArrayList<DataBedak> listproduct;
    ArrayList<Login> listProduct;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_login);
        getSupportActionBar().hide();

        //sharedPreferences
        sharedPreferences = getSharedPreferences("pref_product", MODE_PRIVATE);
        sharedPreferences.contains("listproduct");
        listProduct = new ArrayList<Login>();
        //mengambil shared pref yang sudah ada
        if(sharedPreferences.contains("listproduct")){
            Gson getgson = new Gson();
            String getjsonText = sharedPreferences.getString("listproduct", null);
            Login[] product = getgson.fromJson(getjsonText, Login[].class);
            for (Login product1 : product) {
                listProduct.add(product1);
            }
        }

        //String email = sharedPreferences.getString("email", null);

        //Register
        tvRegister = (TextView) findViewById(R.id.tvRegister);
        tvRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainLogin.this,MainRegister.class);
                startActivity(intent);
                finish();
            }
        });

        etEmail=(EditText) findViewById(R.id.etEmail);
        etPassword=(EditText) findViewById(R.id.etPassword);
        btnDisplay = findViewById(R.id.btnDisplay);

        imgbtnLogin=(ImageButton) findViewById(R.id.imgbtnLogin);
        imgbtnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                prosesLogin(etEmail.getText().toString(),etPassword.getText().toString());
                Login produk = new Login(etEmail.getText().toString(), etPassword.getText().toString());
                listProduct.add(produk);
                Gson gson = new Gson();
                String jsonText = gson.toJson(listProduct);
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putString("listproduct", jsonText);
                editor.apply();
                Toast.makeText(getApplicationContext(), "Simpan ke sharedpreferences",
                        Toast.LENGTH_LONG).show();

            }
        });
        btnDisplay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainLogin.this, MainDisplay.class);
                startActivity(intent);
            }
        });
    }
    public boolean isEmailValid(String email){
        boolean isValid = false;

        String expression = "^[\\w\\.-]+@([\\w\\-]+\\.)+[A-Z]{2,4}$";
        CharSequence inputStr = email;

        Pattern pattern = Pattern.compile(expression, Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(inputStr);
        if (matcher.matches()){
            isValid = true;
        }
        return isValid;
    }

    void prosesLogin(String vemail, String vpassword){
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        RegisterAPI api = retrofit.create(RegisterAPI.class);
        if (!isEmailValid(etEmail.getText().toString())){
            AlertDialog.Builder msg = new AlertDialog.Builder(MainLogin.this);

            msg.setMessage("Email Tidak Valid").setNegativeButton("Retry",null).create().show();
            return;
        }
        api.login(vemail, vpassword).enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                try {
                    JSONObject json = new JSONObject(response.body().string());

                    //cek apakah user ditemukan atau tidak
                    if (json.getString("result").toString().equals("1")) {
                        //cek status aktif atau tidak

                        Toast.makeText(MainLogin.this, "Login Berhasil",
                                Toast.LENGTH_SHORT).show();
                        // SharedPreferences
                        SharedPreferences sharedPreferences = getSharedPreferences("login", MODE_PRIVATE);

                        SharedPreferences.Editor editor = sharedPreferences.edit();

                        Intent intent = new Intent(MainLogin.this, MainActivity.class);
                        intent.putExtra("nama", json.getJSONObject("data").getString("nama"));
                        intent.putExtra("email", json.getJSONObject("data").getString("email"));
                        startActivity(intent);
                        finish();

                    } else {
                        AlertDialog.Builder msg = new AlertDialog.Builder(MainLogin.this);
                        msg.setMessage("Email atau Password Salah")
                                .setNegativeButton("retry", null)
                                .create().show();
                    }
                } catch (JSONException | IOException e) {
                    e.printStackTrace();
                }
            }
            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                Log.i("Info Load","Load Gagal "+t.toString());
            }
        });
    }
}
