package com.example.tokoelisha1;

public class Login {
    String email;

    String password;

    public Login(String email, String password){
        this.email=email;
        this.password=password;

    }

    public  String getEmail(){return email;}
    public  String getPassword() {
        return password;
    }
}
