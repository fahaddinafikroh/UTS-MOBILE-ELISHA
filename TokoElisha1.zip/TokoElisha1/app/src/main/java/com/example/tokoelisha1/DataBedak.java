package com.example.tokoelisha1;

public class DataBedak {

    String foto, merk, deskripsi, stok, kode, status, kategori, satuan, hargapokok;
    double hargajual;
    int qty;

    public DataBedak(String kode, String merk, Double hargajual, String foto, int i) {
        this.kode = kode;
        this.merk = merk;
        this.hargajual = hargajual;
        this.foto = foto;
        this.qty = qty;
    }

    //double harga;

    public String getFoto(){
        return foto;
    }
    public String getKode(){
        return kode;
    }
    public String getMerk(){
        return merk;
    }
    public String getDeskripsi(){
        return deskripsi;
    }
    public Double getHarga(){
        return hargajual;
    }
    public String getStok(){
        return stok;
    }
    public String getHargapokok(){
        return hargapokok;
    }
    public String getStatus(){
        return status;
    }
    public String getKategori(){
        return kategori;
    }
    public String getSatuan(){
        return satuan;
    }
    public Integer getQty(){
        return qty;
    }
    public void setHargaJual(double hargajual) {
        this.hargajual = hargajual;
    }
    public void setQty(int qty) {
        this.qty = qty;
    }
    public void setKode(String kode) {
        this.kode = kode;
    }
}
