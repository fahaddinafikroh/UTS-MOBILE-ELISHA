package com.example.tokoelisha1;

public class DataPelanggan {
    private String email, nama, alamat, kota, provinsni, kodepos, telp, password;
    public void setEmail(String email){this.email=email;}
    public void setNama(String nama){this.nama=nama;}
    public void setAlamat(String alamat){this.alamat=alamat;}
    public void setKota(String kota){this.kota=kota;}
    public void setProvinsni(String provinsni){this.provinsni=provinsni;}
    public void setKodepos(String kodepos){this.kodepos=kodepos;}
    public void setTelp(String telp){this.telp=telp;}
    //public void setPassword(String telp){this.password=password;}

    public String getEmail(){return email;}
    public String getNama(){return nama;}
    public String getAlamat(){return alamat;}
    public String getKota(){return kota;}
    public String getProvinsni(){return provinsni;}
    public String getKodepos(){return kodepos;}
    public String getTelp(){return telp;}
    //public String getPassword(){return password;}
}
