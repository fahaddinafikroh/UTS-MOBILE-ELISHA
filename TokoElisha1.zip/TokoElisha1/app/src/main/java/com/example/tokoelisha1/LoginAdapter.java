package com.example.tokoelisha1;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class LoginAdapter extends RecyclerView.Adapter<LoginAdapter.ViewHolder> {

    ArrayList<Login> listProduct;

    public LoginAdapter(ArrayList<Login> listProduct) {this.listProduct=listProduct;}
    @NonNull
    @Override
    public  LoginAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType){
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View listItem = layoutInflater.inflate(R.layout.list_login, parent, false);
        ViewHolder viewHolder = new  ViewHolder(listItem);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull LoginAdapter.ViewHolder holder, int position){
        final Login listProduct = this.listProduct.get(position);
        holder.etEmail.setText(this.listProduct.get(position).getEmail());
        holder.etPassword.setText(this.listProduct.get(position).getPassword());
    }
    @Override
    public int getItemCount(){

        return listProduct.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder{

        TextView etEmail, etPassword;

        public ViewHolder(@NonNull View itemView){
            super(itemView);

            this.etEmail = (TextView) itemView.findViewById(R.id.tvEmail);
            this.etPassword = (TextView) itemView.findViewById(R.id.tvPassword);


        }
    }
}
