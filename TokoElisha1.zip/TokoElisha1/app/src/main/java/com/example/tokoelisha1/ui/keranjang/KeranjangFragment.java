package com.example.tokoelisha1.ui.keranjang;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


import com.example.tokoelisha1.DataBedak;
import com.example.tokoelisha1.KeranjangAdapter;
import com.example.tokoelisha1.databinding.FragmentKeranjangBinding;
import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class KeranjangFragment extends Fragment {
    ArrayList<DataBedak> results;

    SharedPreferences sharedPreferences;

    Button btnSimpan, btnDisplay;

    KeranjangAdapter mKeranjangAdapter;

    private FragmentKeranjangBinding binding;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        KeranjangViewModel dashboardViewModel =
                new ViewModelProvider(this).get(KeranjangViewModel.class);

        binding = FragmentKeranjangBinding.inflate(inflater, container, false);
        View root = binding.getRoot();
        ArrayList<DataBedak> listproduct = new ArrayList<>();



        sharedPreferences = getContext().getSharedPreferences("keranjang", Context.MODE_PRIVATE);
        if(sharedPreferences.contains("product")) {
            sharedPreferences = getContext().getSharedPreferences("keranjang", Context.MODE_PRIVATE);
            Gson gson = new Gson();
            String jsonText = sharedPreferences.getString("product", null);
            DataBedak[] product = gson.fromJson(jsonText, DataBedak[].class);
            Map<String, DataBedak> map = new HashMap<>();
            double totalHarga = 0;
            for (DataBedak product1 : product) {
                listproduct.add(product1);
                Double harga = product1.getHarga();
                totalHarga += harga;

            }
            Log.i("info pref", "" + listproduct.toString());
            Log.d("TAG", "Total Harga: " + totalHarga);

        }


        RecyclerView recyclerView = binding.recyclerView;
        KeranjangAdapter adapter = new KeranjangAdapter(listproduct);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new GridLayoutManager(getActivity(), 1));
        recyclerView.setAdapter(adapter);
        adapter.notifyDataSetChanged();

        //final TextView textView = binding.textDashboard;
        //dashboardViewModel.getText().observe(getViewLifecycleOwner(), textView::setText);
        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}