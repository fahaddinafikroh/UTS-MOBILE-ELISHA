package com.example.tokoelisha1;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class KeranjangAdapter extends RecyclerView.Adapter<KeranjangAdapter.ViewHolder>{
    ArrayList<DataBedak> listProduct;
    private Context context;

    private List<DataBedak> results;

    KeranjangAdapter adapter;

    public KeranjangAdapter(ArrayList<DataBedak> listProduct) { this.listProduct=listProduct; }
    @NonNull
    @Override
    public KeranjangAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View listItem = layoutInflater.inflate(R.layout.list_keranjang, parent, false);
        ViewHolder viewHolder = new ViewHolder(listItem);
        return viewHolder;
    }


    @Override
    public void onBindViewHolder(@NonNull KeranjangAdapter.ViewHolder holder, @SuppressLint("RecyclerView") int position){

        final DataBedak listProduct = this.listProduct.get(position);
        holder.tvProduct.setText(this.listProduct.get(position).getMerk());
        holder.tvPrice.setText("Rp. "+this.listProduct.get(position).getHarga());
        holder.tvQty.setText("Qty : "+this.listProduct.get(position).getQty());

        String URL_FOTO = "http://192.168.152.142:8080/mobile2/UTS_ELISHA/gambar";

        LoadImage loadImage = new LoadImage(holder.imgCart);
        loadImage.execute(URL_FOTO+"/"+this.listProduct.get(position).getFoto());

        holder.btHapus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SharedPreferences sharedPreferences = view.getContext().getSharedPreferences("cart", Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPreferences.edit();
                String data = sharedPreferences.getString("product", "");
                Gson gson = new Gson();
                Type type = new TypeToken<ArrayList<DataBedak>>(){}.getType();
                ArrayList<DataBedak> arrayList = gson.fromJson(data, type);
                arrayList.remove(position);
                String dataBaru = gson.toJson(arrayList);
                editor.putString("product", dataBaru);
                editor.apply();
            }
        });
    }
    @Override
    public int getItemCount() {
        if(listProduct==null) return 0;
        return listProduct.size();
    }


    public static class ViewHolder extends RecyclerView.ViewHolder{
        TextView tvProduct, tvPrice, tvQty;
        ImageView imgCart;
        ImageButton btHapus;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            this.tvProduct = (TextView) itemView.findViewById(R.id.tvProduct);
            this.tvPrice = (TextView) itemView.findViewById(R.id.tvPrice);
            this.tvQty = (TextView) itemView.findViewById(R.id.tvQty);
            this.imgCart = (ImageView) itemView.findViewById(R.id.imgCart);
            //this.btHapus = (ImageButton) itemView.findViewById(R.id.btnHapus);

        }
    }
}
