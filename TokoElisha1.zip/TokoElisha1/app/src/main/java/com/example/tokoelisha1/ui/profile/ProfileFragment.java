package com.example.tokoelisha1.ui.profile;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;


import com.example.tokoelisha1.MainEditProfile;
import com.example.tokoelisha1.MainLogin;
import com.example.tokoelisha1.databinding.FragmentProfileBinding;

public class ProfileFragment extends Fragment {
    ImageButton imgbtnLogut, imbtnEditProfile;
    TextView tvwelcome;
    ImageButton imgbtnProduct, imgbtnKontak;

    private FragmentProfileBinding binding;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        ProfileViewModel notificationsViewModel =
                new ViewModelProvider(this).get(ProfileViewModel.class);

        binding = FragmentProfileBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        //WELCOME


        tvwelcome = binding.welcome;
        tvwelcome.setText("Welcome : "+ getActivity().getIntent().getStringExtra("nama") +
                " ("+ getActivity().getIntent().getStringExtra("email") + ")");

        //LOGOUT
        ImageButton imgbtnLogut = binding.imgbtnLogut;
        imgbtnLogut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getActivity(), MainLogin.class);
                startActivity(intent);
                getActivity().finish();
            }
        });

        //EDIT PROFILE
        //ImageButton imbtnEditProfile = binding.imgbtnEditProfile;
        //imbtnEditProfile.setOnClickListener(new View.OnClickListener() {
            //@Override
            //public void onClick(View view) {
                //Intent intent = new Intent(view.getContext(), MainEditProfile.class);
                //intent.putExtra("nama", intent.getStringExtra("nama"));
                //intent.putExtra("email", intent.getStringExtra("email"));
                //startActivity(intent);
                //getActivity().finish();
           // }
       // });

        //EDIT PROFILE
        imbtnEditProfile = binding.imgbtnEditProfile;;
        imbtnEditProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getActivity(), MainEditProfile.class);
                intent.putExtra("nama",getActivity().getIntent().getStringExtra("nama"));
                intent.putExtra("email",getActivity().getIntent().getStringExtra("email"));
                startActivity(intent);
            }
        });




        //final TextView textView = binding.textNotifications;
        //notificationsViewModel.getText().observe(getViewLifecycleOwner(), textView::setText);
        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}