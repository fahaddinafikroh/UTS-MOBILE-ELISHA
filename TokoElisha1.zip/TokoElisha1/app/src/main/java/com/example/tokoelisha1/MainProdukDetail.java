package com.example.tokoelisha1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class MainProdukDetail extends AppCompatActivity {

    TextView tvKodeDetail, tvMerkDetail, tvKembali1, tvStokDetail, tvDeskripsiDetail, tvHargaDetail, tvKategoriDetail, tvStatusDetail, tvSatuanDetail;
    ImageView imgGambar1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_produk_detail);
        getSupportActionBar().hide();
        //TV KEMABLI KE HOME
        tvKembali1 = (TextView) findViewById(R.id.tvKembali1);
        tvKembali1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
        //getSupportActionBar().setTitle("Daftar Obat Penurun Panas");

//        viewAdapter = new ObatAdapter(this, results);
//        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
//        recyclerView = (RecyclerView) findViewById(R.id.recycleView);
//        recyclerView.setItemAnimator(new DefaultItemAnimator());
//        recyclerView.setAdapter(viewAdapter);
//        recyclerView.setLayoutManager(new GridLayoutManager(this,2));
//
//        LoadDataObat();
        tvKodeDetail = (TextView) findViewById(R.id.tvKode);
        tvMerkDetail = (TextView) findViewById(R.id.tvMerk);
        tvStokDetail = (TextView) findViewById(R.id.tvStok);
        tvDeskripsiDetail = (TextView) findViewById(R.id.tvDeskripsi);
        tvHargaDetail = (TextView) findViewById(R.id.tvHarga);
        tvKategoriDetail = (TextView) findViewById(R.id.tvKategori);
        tvStatusDetail = (TextView) findViewById(R.id.tvStatus);
        tvSatuanDetail = (TextView) findViewById(R.id.tvSatuan);
        imgGambar1 = (ImageView) findViewById(R.id.ivFoto);

        Intent intent = getIntent();
        String kode = intent.getStringExtra("kode");
        String merk = intent.getStringExtra("merk");
        String stok = intent.getStringExtra("stok");
        String satuan = intent.getStringExtra("satuan");
        String deskripsi = intent.getStringExtra("deskripsi");
        String hargapokok = intent.getStringExtra("hargapokok");
        String kategori = intent.getStringExtra("kategori");
        String status = intent.getStringExtra("status");
        String img = intent.getStringExtra("foto");

        tvKodeDetail.setText(kode);
        tvMerkDetail.setText(merk);
        tvStokDetail.setText(stok);
        tvDeskripsiDetail.setText(deskripsi);
        tvHargaDetail.setText("Rp. "+hargapokok+"");
        tvKategoriDetail.setText(kategori);
        tvSatuanDetail.setText(satuan);
        tvStatusDetail.setText(status);

        String URL_FOTO ="http://192.168.152.142:8080/mobile2/UTS_ELISHA/gambar/";
        LoadImage loadImage = new LoadImage(imgGambar1);
        loadImage.execute(URL_FOTO+"/"+img+"");

    }
}