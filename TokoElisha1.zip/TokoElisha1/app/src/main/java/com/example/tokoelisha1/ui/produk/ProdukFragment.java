package com.example.tokoelisha1.ui.produk;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


import com.example.tokoelisha1.BedakAdapter;
import com.example.tokoelisha1.DataBedak;
import com.example.tokoelisha1.RegisterAPI;
import com.example.tokoelisha1.Value;
import com.example.tokoelisha1.databinding.FragmentProdukBinding;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class ProdukFragment extends Fragment {
    TextView tvWelcome;
    public  static final String URL = "http://192.168.152.142:8080/mobile2/UTS_ELISHA/";
    private List<DataBedak> results = new ArrayList<>();
    private BedakAdapter viewAdapter;
    RecyclerView recyclerView;
    //TextView tvBack;

    private FragmentProdukBinding binding;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        ProdukViewModel produkViewModel =
                new ViewModelProvider(this).get(ProdukViewModel.class);

        binding = FragmentProdukBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        //WELCOME


        tvWelcome = binding.welcome1;
        tvWelcome.setText("Welcome : "+ getActivity().getIntent().getStringExtra("nama") +
                " ("+ getActivity().getIntent().getStringExtra("email") + ")");


         //TextView tvwelcome = binding.tvProfileWelcome;
        //tvWelcome.setText("Welcome : " + getArguments().getString("nama") +
                //"(" + getArguments().getString("email") + ")");
       
        //etSupportActionBar().hide();
        //getSupportActionBar().setTitle("Daftar Katalog Obat Penurun Panas");
        viewAdapter = new BedakAdapter(getContext(), results);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getContext());
        recyclerView = binding.recycleView;
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(viewAdapter);
        recyclerView.setLayoutManager(new GridLayoutManager(getContext(), 2));

        LoadDataBedak();

        //tvBack = binding.tvKembali;
        //tvBack.setOnClickListener(new View.OnClickListener() {
            //@Override
            //public void onClick(View view) {
                //getActivity().finish();
        //}
        //});

        //final TextView textView = binding.textHome;
        //homeViewModel.getText().observe(getViewLifecycleOwner(), textView::setText);
        return root;
    }

    private void LoadDataBedak(){
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        RegisterAPI api = retrofit.create(RegisterAPI.class);
        Call<Value> call = api.view();
        Log.i("Info Load", "Load Data Bedak Diakses");
        call.enqueue(new Callback<Value>(){
            @Override
            public void onResponse(Call<Value> call1, Response<Value> response){
                String value = response.body().getValue();
                results = response.body().getResult();
                Log.i("Info Load", "Respon Body, Persiapan Masuk Adapter");
                viewAdapter = new BedakAdapter(getContext(), results);
                recyclerView.setAdapter(viewAdapter);
            }

            @Override
            public void onFailure(Call<Value> call1, Throwable t){
                Log.i("Info Laoad", "Load Gagal"+t.toString());
            }
        });
    }
    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}