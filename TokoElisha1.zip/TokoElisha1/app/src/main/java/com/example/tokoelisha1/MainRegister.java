package com.example.tokoelisha1;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainRegister extends AppCompatActivity {

    TextView tvBack;
    EditText etNama, etEmail, etPassword;
    ImageButton imgbtnSubmit;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_register);
        getSupportActionBar().hide();
        tvBack = (TextView) findViewById(R.id.tvBack);
        tvBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainRegister.this,MainLogin.class);
                startActivity(intent);
                finish();
            }
        });

        etEmail = (EditText) findViewById(R.id.etEmail);
        etNama = (EditText) findViewById(R.id.etNama);
        etPassword = (EditText) findViewById(R.id.etPassword);

        imgbtnSubmit = (ImageButton) findViewById(R.id.imgbtnSubmit);
        imgbtnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                prosesSubmit(etEmail.getText().toString(),
                        etNama.getText().toString(),
                        etPassword.getText().toString());
            }
        });
    }
    public boolean isEmailValid(String email){
        boolean isValid = false;

        String expression = "^[\\w\\.-]+@([\\w\\-]+\\.)+[A-Z]{2,4}$";
        CharSequence inputStr = email;

        Pattern pattern = Pattern.compile(expression, Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(inputStr);
        if (matcher.matches()){
            isValid = true;
        }
        return isValid;
    }

    void prosesSubmit(String vemail, String vnama, String vpassword){
        String URL = "http://192.168.152.142:8080/mobile2/UTS_ELISHA/";

        Retrofit retrofit = new Retrofit.Builder().baseUrl(URL).addConverterFactory(GsonConverterFactory.create()).build();
        RegisterAPI api = retrofit.create(RegisterAPI.class);
        //cek apakah email sudah valid
        if (!isEmailValid(etEmail.getText().toString())){
            AlertDialog.Builder msg = new AlertDialog.Builder(MainRegister.this);

            msg.setMessage("Email Tidak Valid").setNegativeButton("Retry",null).create().show();
            return;
        }

        api.register(vemail,vnama,vpassword).enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                try {
                    JSONObject json = new JSONObject(response.body().string());
                    //cek apakah user sudah ada atau tidak
                    if (json.getString("status").toString().equals("1")){
                        //cek result apakah berhasil tersimpan atau tidak
                        if (json.getString("result").toString().equals("1")){
                            AlertDialog.Builder msg = new AlertDialog.Builder(MainRegister.this);
                            msg.setMessage("Register Berhasil").setPositiveButton("OK",null).create().show();
                            etEmail.setText("");
                            etNama.setText("");
                            etPassword.setText("");
                        }
                        else {
                            AlertDialog.Builder msg = new AlertDialog.Builder(MainRegister.this);
                            msg.setMessage("Simpan Gagal").setNegativeButton("retry",null).create().show();
                        }
                    }else {
                        AlertDialog.Builder msg = new AlertDialog.Builder(MainRegister.this);
                        msg.setMessage("User Sudah Ada").setNegativeButton("retry",null).create().show();
                    }
                }catch (JSONException | IOException e){
                    e.printStackTrace();
                }
            }
            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                Log.i("Info Register","Register Gagal"+t.toString());
            }
        });
    }
  }
