package com.example.tokoelisha1;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;


import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class BedakAdapter extends RecyclerView.Adapter<BedakAdapter.ViewHolder> {
    private Context context;
    private List<DataBedak> results;

    ArrayList<DataBedak> listProduct;
    SharedPreferences sharedPreferences;

    public BedakAdapter(Context context , List<DataBedak> results) {
        this.context = context;
        this.results = results;
    }

    @NonNull
    @Override
    public BedakAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType){
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_bedak,
                parent, false);
        ViewHolder holder = new ViewHolder(v);
        return  holder;
    }

    @Override
    public void onBindViewHolder(@NonNull BedakAdapter.ViewHolder holder, int position){
        sharedPreferences = context.getSharedPreferences("cart", Context.MODE_PRIVATE);
        sharedPreferences.contains("product");
        listProduct = new ArrayList<DataBedak>();
        //mengambil shared pref yang sudah ada
        if(sharedPreferences.contains("product")) {
            Gson getgson = new Gson();
            String getjsonText = sharedPreferences.getString("product", null);
            DataBedak[] product = getgson.fromJson(getjsonText, DataBedak[].class);
            for (DataBedak product1 : product) {
                listProduct.add(product1);
            }
        }

        DataBedak result = results.get(position);
        holder.tvMerk.setText(result.getMerk());
        //holder.tvDeskripsi.setText(result.getDeskripsi());
        //String Harga Jual Nuber Format
        //holder.tvHargajual.setText("Rp. "+ NumberFormat.getNumberInstance(Locale.getDefault()).
        //format(result.getHarga()));
        holder.tvHargajual.setText("Rp. "+result.getHarga());
        holder.tvStatus.setText(result.getStatus());
        //holder.tvStok.setText(result.getStok());

        String URL_FOTO = "http://192.168.152.142:8080/mobile2/UTS_ELISHA/gambar/";

        LoadImage loadImage = new LoadImage(holder.ivFoto);
        loadImage.execute(URL_FOTO+"/"+result.getFoto());

        holder.imbtnDetail.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                Toast.makeText(context,result.getKode(), Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(context, MainProdukDetail.class);
                intent.putExtra("kode", result.getKode());
                intent.putExtra("merk", result.getMerk());
                intent.putExtra("hargapokok", result.getHargapokok());
                intent.putExtra("stok", result.getStok());
                intent.putExtra("deskripsi", result.getDeskripsi());
                intent.putExtra("kategori", result.getKategori());
                intent.putExtra("status", result.getStatus());
                intent.putExtra("satuan", result.getSatuan());
                intent.putExtra("foto", result.getFoto());
                context.startActivity(intent);
            }
        });
        holder.btnCart.setOnClickListener(new View.OnClickListener() {
            int qty = 1;
            @Override
            public void onClick(View view) {


                Toast.makeText(context, "Data ditambahkan ke keranjang", Toast.LENGTH_SHORT).show();
                Gson gson = new Gson();
                String json = sharedPreferences.getString("product", null);
                Type type = new TypeToken<ArrayList<DataBedak>>() {}.getType();
                listProduct = gson.fromJson(json, type);
                ArrayList<DataBedak> listProduct = new ArrayList<>();

                sharedPreferences = context.getSharedPreferences("cart", Context.MODE_PRIVATE);
                //mengambil shared pref yang sudah ada
                if(sharedPreferences.contains("product")) {
                    Gson getgson = new Gson();
                    String getjsonText = sharedPreferences.getString("product", null);
                    DataBedak[] product = getgson.fromJson(getjsonText, DataBedak[].class);
                    for (DataBedak product1 : product) {
                        listProduct.add(product1);
                    }
                }

                boolean itemFound = true;
                for (DataBedak barang : listProduct) {
                    if (barang.getKode().equals(result.kode)) {
                        barang.setHargaJual(barang.getHarga() + result.hargajual);
                        barang.setQty(barang.getQty() + qty);
                        itemFound = false;
                        break;
                    }
                }

                if (itemFound) {
                    DataBedak produk1 = new DataBedak(result.getKode(), result.getMerk(),
                            result.getHarga(), result.getFoto(), 1);
                    listProduct.add(produk1);
                }
                SharedPreferences.Editor editor = sharedPreferences.edit();
                String json1 = gson.toJson(listProduct);
                editor.putString("product", json1);
                editor.apply();
            }
        });
    }

    @Override
    public int getItemCount(){
        return results.size();
    }
    public class ViewHolder extends RecyclerView.ViewHolder{
        public TextView tvMerk, tvHargajual, tvStatus;
        public ConstraintLayout layout;
        public ImageView ivFoto;
        public ImageButton imbtnDetail, btnCart;

        public ViewHolder(View itemView){
            super(itemView);
            this.tvMerk = (TextView) itemView.findViewById(R.id.tvMerk);
            // this.tvDeskripsi = (TextView) itemView.findViewById(R.id.tvDeskripsi);
            this.tvHargajual = (TextView) itemView.findViewById(R.id.tvHarga);
            this.tvStatus = (TextView) itemView.findViewById(R.id.tvStatus);
            this.ivFoto = (ImageView) itemView.findViewById(R.id.ivFoto);
            this.imbtnDetail = (ImageButton) itemView.findViewById(R.id.imbtnDetail);
            this.btnCart = (ImageButton) itemView.findViewById(R.id.btnCart);
            layout = (ConstraintLayout) itemView.findViewById(R.id.constrainLayout);
        }
    }
}
